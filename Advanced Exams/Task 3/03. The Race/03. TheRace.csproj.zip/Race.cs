﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TheRace
{
    public class Race
    {
        //• Field data – collection that holds added racers
        private List<Racer> racers;
        public Race(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            racers = new List<Racer>();
        }

        public string Name { get; set; }
        public int Capacity { get; set; }

        //• Getter Count – returns the number of racers.
        public int Count => racers.Count;


        //• Method Add(Racer Racer) – adds an entity to the data if there is room for him/her.
        public void Add(Racer racer)
        {
            if (!racers.Contains(racer) && racers.Count < Capacity)
            {
                racers.Add(racer);
            }
        }

        //• Method Remove(string name) – removes an Racer by given name, if such exists, and returns bool.
        public bool Remove(string name)
        {
            Racer racerToRemove = racers.FirstOrDefault(p => p.Name == name);

            if (racerToRemove != null)
            {
                racers.Remove(racerToRemove);
            }

            return false;
        }

        //• Method GetOldestRacer() – returns the oldest Racer.
        public Racer GetOldestRacer()
        {
            Racer oldestRacer = racers.OrderByDescending(r => r.Age)
                .FirstOrDefault();
            return oldestRacer;
        }

        //• Method GetRacer(string name) – returns the Racer with the given name.
        public Racer GetRacer(string name)
        {
            Racer currentRacer = racers.Find(r => r.Name == name);
            return currentRacer;
        }

        //• Method GetFastestRacer() – returns the Racer whose car has the highest speed.
        public Racer GetFastestRacer()
        {
            Racer fastestRacer = racers.OrderByDescending(r => r.Car.Speed).FirstOrDefault();
            return fastestRacer;
        }

        //• Report() – returns a string in the following format:
        public string Report()
        {
            var result = $"racers participating at {Name}\n";
            foreach (Racer racer in racers)
            {
                result += $"{racer}\n";
            }
            return result.TrimEnd();
        }
        //o "racers participating at {RaceName}:
        //{Racer1} 
        //{Racer2}
    }
}

